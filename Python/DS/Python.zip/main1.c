main()
{
	int x = 5;	
	if(x++ == ++x)
		printf("Hello\n");
	else
		printf("Hi\n");
}
