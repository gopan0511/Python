class vector:
	dir = None
	mag = None

	def __init__(self,dir,mag):
		self.dir = dir
		self.mag = mag


