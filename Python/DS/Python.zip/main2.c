main()
{
	int no;
	printf("Enter the number\n");
	scanf("%d",&no);

	if(no & 1)
		printf("Odd\n");
	else
		printf("Even\n");
}
