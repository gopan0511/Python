a = input("Enter a: ")
b = input("Enter b: ")

if a>b:
	print "%d is max" %a
else:
	print "%d is max" %b
